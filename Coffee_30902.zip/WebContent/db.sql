<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" %>

set autocommit on;

create table tbl_pizaa_01
(
		pcode varchar2(4) PRIMARY KEY
	,	name varchar2(30)
	,	cost number(7)
);

create table tbl_shop_01
(
	scode char(4) PRIMARY KEY
,	sname varchar(20)
);

create table tbl_salelist_01
(
	
		saleno number(7) PRIMARY KEY
	,	scode char(4)
	,	saledate date
	,	pcode	varchar2(4)
	,	amount	number(5)
	,	CONSTRAINT tb_salelist_scode_fk FOREIGN KEY(scode)
			REFERENCES tbl_shop_01(scode)
	,	CONSTRAINT tb_salelist_pcode_fk FOREIGN KEY(pcode)
			REFERENCES tbl_pizza_01(pcode)
);
